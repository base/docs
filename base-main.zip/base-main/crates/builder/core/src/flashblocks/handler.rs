use base_execution_payload_builder::BaseBuiltPayload;
use base_node_core::BaseEngineTypes;
use reth_node_builder::Events;
use tokio::sync::mpsc;
use tracing::{debug, warn};

/// Handles newly built flashblock payloads.
///
/// In the case of a payload built by this node, it is broadcast to peers and an event is sent to the payload builder.
/// In the case of a payload received from a peer, it is executed and if successful, an event is sent to the payload builder.
#[derive(Debug)]
pub struct PayloadHandler {
    // receives new payloads built by this builder.
    built_rx: mpsc::Receiver<BaseBuiltPayload>,
    // sends a `Events::BuiltPayload` to the reth payload builder when a new payload is received.
    payload_events_handle: tokio::sync::broadcast::Sender<Events<BaseEngineTypes>>,
}

impl PayloadHandler {
    /// Constructs a new `PayloadHandler`.
    pub const fn new(
        built_rx: mpsc::Receiver<BaseBuiltPayload>,
        payload_events_handle: tokio::sync::broadcast::Sender<Events<BaseEngineTypes>>,
    ) -> Self {
        Self { built_rx, payload_events_handle }
    }

    /// Runs the payload handler, listening for new built payloads
    /// and forwarding them to the payload builder via events.
    pub async fn run(self) {
        let Self { mut built_rx, payload_events_handle } = self;

        debug!("flashblocks payload handler started");

        loop {
            tokio::select! {
                Some(payload) = built_rx.recv() => {
                    if let Err(e) = payload_events_handle.send(Events::BuiltPayload(payload)) {
                        warn!(e = ?e, "failed to send BuiltPayload event");
                    }
                }
                else => break,
            }
        }
    }
}
