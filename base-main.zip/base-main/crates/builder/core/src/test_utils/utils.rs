use core::future::Future;
use std::{net::TcpListener, sync::Arc};

use alloy_eips::Encodable2718;
use alloy_primitives::{Address, B256, BlockHash, TxHash, TxKind, U256, hex};
use alloy_rpc_types_eth::{Block, BlockTransactionHashes};
use alloy_sol_types::SolCall;
use base_common_consensus::{BaseTypedTransaction, TxDeposit};
use base_common_rpc_types::Transaction;
use base_execution_chainspec::BaseChainSpec;
use reth_db::{
    ClientVersion, DatabaseEnv, init_db,
    mdbx::{DatabaseArguments, KILOBYTE, MEGABYTE, MaxReadTransactionDuration},
    test_utils::{ERROR_DB_CREATION, TempDatabase},
};
use reth_node_core::{args::DatadirArgs, dirs::DataDirPath, node_config::NodeConfig};

use super::{
    BUILDER_PRIVATE_KEY, FLASHBLOCKS_DEPLOY_KEY, FUNDED_PRIVATE_KEY, PrivateKeySigner, Protocol,
    TransactionBuilder, driver::ChainDriver, flashblocks_number_contract::FlashblocksNumber,
    sign_op_tx,
};

/// Extension methods on [`TransactionBuilder`] for common test transaction patterns.
pub trait TransactionBuilderExt {
    /// Configures a simple ETH transfer to a random address.
    fn random_valid_transfer(self) -> Self;
    /// Configures a contract creation whose bytecode immediately reverts.
    fn random_reverting_transaction(self) -> Self;
    /// Configures a contract creation that consumes approximately 86 220 gas.
    fn random_big_transaction(self) -> Self;
    // flashblocks number methods
    /// Configures deployment of the `FlashblocksNumber` contract.
    fn deploy_flashblock_number_contract(self) -> Self;
    /// Configures an `initialize` call on the `FlashblocksNumber` contract.
    fn init_flashblock_number_contract(self, register_builder: bool) -> Self;
    /// Configures an `addBuilder` call to authorize a builder address.
    fn add_authorized_builder(self, builder: Address) -> Self;
}

impl TransactionBuilderExt for TransactionBuilder {
    fn random_valid_transfer(self) -> Self {
        self.with_to(rand::random::<Address>()).with_value(1)
    }

    fn random_reverting_transaction(self) -> Self {
        self.with_create().with_input(hex!("60006000fd").into()) // PUSH1 0x00 PUSH1 0x00 REVERT
    }

    // This transaction is big in the sense that it uses a lot of gas. The exact
    // amount it uses is 86220 gas.
    fn random_big_transaction(self) -> Self {
        // PUSH13 0x63ffffffff60005260046000f3 PUSH1 0x00 MSTORE PUSH1 0x02 PUSH1 0x0d PUSH1 0x13 PUSH1 0x00 CREATE2
        self.with_create()
            .with_input(hex!("6c63ffffffff60005260046000f36000526002600d60136000f5").into())
    }

    fn deploy_flashblock_number_contract(self) -> Self {
        self.with_create()
            .with_input(FlashblocksNumber::BYTECODE.clone())
            .with_gas_limit(2_000_000) // deployment costs ~1.6 million gas
            .with_signer(&flashblocks_number_signer())
    }

    fn init_flashblock_number_contract(self, register_builder: bool) -> Self {
        let builder_signer = builder_signer();
        let owner = flashblocks_number_signer();

        let init_data = FlashblocksNumber::initializeCall {
            _owner: owner.address(),
            _initialBuilders: if register_builder {
                vec![builder_signer.address()]
            } else {
                vec![]
            },
        }
        .abi_encode();

        self.with_input(init_data.into()).with_signer(&flashblocks_number_signer())
    }

    fn add_authorized_builder(self, builder: Address) -> Self {
        let calldata = FlashblocksNumber::addBuilderCall { builder }.abi_encode();

        self.with_input(calldata.into()).with_signer(&flashblocks_number_signer())
    }
}

/// Extension methods on [`ChainDriver`] for common funding and block-building patterns.
pub trait ChainDriverExt {
    /// Funds multiple addresses by minting via deposit transactions in a single block.
    fn fund_many(
        &self,
        addresses: Vec<Address>,
        amount: u128,
    ) -> impl Future<Output = eyre::Result<BlockHash>>;
    /// Funds a single address by minting via a deposit transaction.
    fn fund(&self, address: Address, amount: u128)
    -> impl Future<Output = eyre::Result<BlockHash>>;

    /// Creates `count` random signers, funds each with `amount` wei, and returns them.
    fn fund_accounts(
        &self,
        count: usize,
        amount: u128,
    ) -> impl Future<Output = eyre::Result<Vec<PrivateKeySigner>>> {
        async move {
            let accounts = (0..count).map(|_| PrivateKeySigner::random()).collect::<Vec<_>>();
            self.fund_many(accounts.iter().map(|a| a.address()).collect(), amount).await?;
            Ok(accounts)
        }
    }

    /// Sends a random valid transfer and builds a new block containing it.
    fn build_new_block_with_valid_transaction(
        &self,
    ) -> impl Future<Output = eyre::Result<(TxHash, Block<Transaction>)>>;

    /// Sends a reverting transaction and builds a new block containing it.
    fn build_new_block_with_reverting_transaction(
        &self,
    ) -> impl Future<Output = eyre::Result<(TxHash, Block<Transaction>)>>;
}

impl<P: Protocol> ChainDriverExt for ChainDriver<P> {
    async fn fund_many(&self, addresses: Vec<Address>, amount: u128) -> eyre::Result<BlockHash> {
        let mut txs = Vec::with_capacity(addresses.len());

        for address in addresses {
            let deposit = TxDeposit {
                source_hash: B256::default(),
                from: address, // Set the sender to the address of the account to seed
                to: TxKind::Create,
                mint: amount, // Amount to deposit
                value: U256::default(),
                gas_limit: 210000,
                is_system_transaction: false,
                input: Default::default(), // No input data for the deposit
            };

            let signer = PrivateKeySigner::random();
            let signed_tx = sign_op_tx(&signer, BaseTypedTransaction::Deposit(deposit))?;
            let signed_tx_rlp = signed_tx.encoded_2718();
            txs.push(signed_tx_rlp.into());
        }

        Ok(self.build_new_block_with_txs(txs).await?.header.hash)
    }

    async fn fund(&self, address: Address, amount: u128) -> eyre::Result<BlockHash> {
        let deposit = TxDeposit {
            source_hash: B256::default(),
            from: address, // Set the sender to the address of the account to seed
            to: TxKind::Create,
            mint: amount, // Amount to deposit
            value: U256::default(),
            gas_limit: 210000,
            is_system_transaction: false,
            input: Default::default(), // No input data for the deposit
        };

        let signer = PrivateKeySigner::random();
        let signed_tx = sign_op_tx(&signer, BaseTypedTransaction::Deposit(deposit))?;
        let signed_tx_rlp = signed_tx.encoded_2718();
        Ok(self.build_new_block_with_txs(vec![signed_tx_rlp.into()]).await?.header.hash)
    }

    async fn build_new_block_with_valid_transaction(
        &self,
    ) -> eyre::Result<(TxHash, Block<Transaction>)> {
        let tx = self.create_transaction().random_valid_transfer().send().await?;
        Ok((*tx.tx_hash(), self.build_new_block().await?))
    }

    async fn build_new_block_with_reverting_transaction(
        &self,
    ) -> eyre::Result<(TxHash, Block<Transaction>)> {
        let tx = self.create_transaction().random_reverting_transaction().send().await?;

        Ok((*tx.tx_hash(), self.build_new_block().await?))
    }
}

/// Convenience methods for checking transaction inclusion in blocks.
pub trait BlockTransactionsExt {
    /// Returns `true` if the block contains all of the given transaction hashes.
    fn includes(&self, txs: &impl AsTxs) -> bool;
}

impl BlockTransactionsExt for Block<Transaction> {
    fn includes(&self, txs: &impl AsTxs) -> bool {
        txs.as_txs().into_iter().all(|tx| self.transactions.hashes().any(|included| included == tx))
    }
}

impl BlockTransactionsExt for BlockTransactionHashes<'_, Transaction> {
    fn includes(&self, txs: &impl AsTxs) -> bool {
        let mut included_tx_iter = self.clone();
        txs.as_txs().iter().all(|tx| included_tx_iter.any(|included| included == *tx))
    }
}

/// Conversion to a list of transaction hashes for inclusion checks.
pub trait AsTxs {
    /// Returns the value as a `Vec<TxHash>`.
    fn as_txs(&self) -> Vec<TxHash>;
}

impl AsTxs for TxHash {
    fn as_txs(&self) -> Vec<TxHash> {
        vec![*self]
    }
}

impl AsTxs for Vec<TxHash> {
    fn as_txs(&self) -> Vec<TxHash> {
        self.clone()
    }
}

/// Creates a temporary MDBX database suitable for tests.
pub fn create_test_db(config: NodeConfig<BaseChainSpec>) -> Arc<TempDatabase<DatabaseEnv>> {
    let path = reth_node_core::dirs::MaybePlatformPath::<DataDirPath>::from(
        reth_db::test_utils::tempdir_path(),
    );
    let db_config =
        config.with_datadir_args(DatadirArgs { datadir: path.clone(), ..Default::default() });
    let data_dir = path.unwrap_or_chain_default(db_config.chain.chain(), db_config.datadir.clone());
    let path = data_dir.db();
    let db = init_db(
        path.as_path(),
        DatabaseArguments::new(ClientVersion::default())
            .with_max_read_transaction_duration(Some(MaxReadTransactionDuration::Unbounded))
            .with_geometry_max_size(Some(4 * MEGABYTE))
            .with_growth_step(Some(4 * KILOBYTE)),
    )
    .expect(ERROR_DB_CREATION);
    Arc::new(TempDatabase::new(db, path))
}

/// Gets an available port by first binding to port 0 -- instructing the OS to
/// find and assign one. Then the listener is dropped when this goes out of
/// scope, freeing the port for the next time this function is called.
pub fn get_available_port() -> u16 {
    TcpListener::bind("127.0.0.1:0")
        .expect("Failed to bind to random port")
        .local_addr()
        .expect("Failed to get local address")
        .port()
}

/// Returns the [`PrivateKeySigner`] for the default builder account.
pub fn builder_signer() -> PrivateKeySigner {
    BUILDER_PRIVATE_KEY.parse().expect("invalid hardcoded builder private key")
}

/// Returns the [`PrivateKeySigner`] for the default pre-funded account.
pub fn funded_signer() -> PrivateKeySigner {
    FUNDED_PRIVATE_KEY.parse().expect("invalid hardcoded funded private key")
}

/// Returns the [`PrivateKeySigner`] for the flashblocks contract deployer account.
pub fn flashblocks_number_signer() -> PrivateKeySigner {
    FLASHBLOCKS_DEPLOY_KEY
        .parse()
        .expect("invalid hardcoded flashblocks number deployer private key")
}
