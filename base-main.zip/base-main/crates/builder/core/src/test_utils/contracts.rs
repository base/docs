/// Solidity ABI bindings for the [`FlashblocksNumber`](https://github.com/Uniswap/flashblocks_number_contract) contract used in integration tests.
pub mod flashblocks_number_contract {
    use alloy_sol_types::sol;
    sol!(
        // https://github.com/Uniswap/flashblocks_number_contract/tree/c21ca0aedc3ff4d1eecf20cd55abeb984080bc78
        #[sol(rpc, abi)]
        FlashblocksNumber,
        "src/test_utils/artifacts/contracts/FlashblocksNumberContract.json",
    );
}
