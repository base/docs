//! A task for importing a block that has already been started.
use std::{sync::Arc, time::Instant};

use alloy_rpc_types_engine::{ExecutionPayload, PayloadId};
use async_trait::async_trait;
use base_common_genesis::RollupConfig;
use base_common_rpc_types_engine::{BaseExecutionPayload, BaseExecutionPayloadEnvelope};
use base_protocol::{AttributesWithParent, L2BlockInfo};
use derive_more::Constructor;
use tokio::sync::mpsc;

use super::SealTaskError;
use crate::{
    EngineClient, EngineGetPayloadVersion, EngineState, EngineTaskExt, InsertTask,
    InsertTaskError::{self},
    task_queue::build_and_seal,
};

/// Task for block sealing and canonicalization.
///
/// The [`SealTask`] handles the following parts of the block building workflow:
///
/// 1. **Payload Construction**: Retrieves the built payload using `engine_getPayload`
/// 2. **Block Import**: Imports the payload using [`InsertTask`] for canonicalization
///
/// ## Error Handling
///
/// The task delegates to [`InsertTaskError`] for payload import failures.
///
/// [`InsertTask`]: crate::InsertTask
/// [`InsertTaskError`]: crate::InsertTaskError
#[derive(Debug, Clone, Constructor)]
pub struct SealTask<EngineClient_: EngineClient> {
    /// The engine API client.
    pub engine: Arc<EngineClient_>,
    /// The [`RollupConfig`].
    pub cfg: Arc<RollupConfig>,
    /// The [`PayloadId`] being sealed.
    pub payload_id: PayloadId,
    /// The [`AttributesWithParent`] to instruct the execution layer to build.
    pub attributes: AttributesWithParent,
    /// Whether or not the payload was derived, or created by the sequencer.
    pub is_attributes_derived: bool,
    /// An optional sender to convey success/failure result of the built
    /// [`BaseExecutionPayloadEnvelope`] after the block has been built, imported, and canonicalized
    /// or the [`SealTaskError`] that occurred during processing.
    pub result_tx: Option<mpsc::Sender<Result<BaseExecutionPayloadEnvelope, SealTaskError>>>,
}

impl<EngineClient_: EngineClient> SealTask<EngineClient_> {
    /// Seals the execution payload in the EL, returning the execution envelope.
    ///
    /// ## Engine Method Selection
    /// The method used to fetch the payload from the EL is determined by the payload timestamp. The
    /// method used to import the payload into the engine is determined by the payload version.
    ///
    /// - `engine_getPayloadV2` is used for payloads with a timestamp before the Ecotone fork.
    /// - `engine_getPayloadV3` is used for payloads with a timestamp after the Ecotone fork.
    /// - `engine_getPayloadV4` is used for Isthmus/Jovian payloads before Base Azul.
    /// - `engine_getPayloadV5` is used for Base Azul / Osaka payloads.
    async fn seal_payload(
        &self,
        cfg: &RollupConfig,
        engine: &EngineClient_,
        payload_id: PayloadId,
        payload_attrs: AttributesWithParent,
    ) -> Result<BaseExecutionPayloadEnvelope, SealTaskError> {
        let payload_timestamp = payload_attrs.attributes().payload_attributes.timestamp;

        debug!(
            target: "engine",
            payload_id = payload_id.to_string(),
            l2_time = payload_timestamp,
            "Sealing payload"
        );

        let get_payload_version = EngineGetPayloadVersion::from_cfg(cfg, payload_timestamp);
        let payload_envelope = match get_payload_version {
            EngineGetPayloadVersion::V5 => {
                let payload = engine.get_payload_v5(payload_id).await.map_err(|e| {
                    error!(target: "engine", error = %e, "Payload fetch failed");
                    SealTaskError::GetPayloadFailed(e)
                })?;

                // V5 drops parent_beacon_block_root from the get_payload response; source it
                // from the attributes instead so InsertTask can still pass it to new_payload.
                BaseExecutionPayloadEnvelope {
                    parent_beacon_block_root: payload_attrs
                        .attributes()
                        .payload_attributes
                        .parent_beacon_block_root,
                    execution_payload: BaseExecutionPayload::V4(payload.execution_payload),
                }
            }
            EngineGetPayloadVersion::V4 => {
                let payload = engine.get_payload_v4(payload_id).await.map_err(|e| {
                    error!(target: "engine", error = %e, "Payload fetch failed");
                    SealTaskError::GetPayloadFailed(e)
                })?;

                BaseExecutionPayloadEnvelope {
                    parent_beacon_block_root: Some(payload.parent_beacon_block_root),
                    execution_payload: BaseExecutionPayload::V4(payload.execution_payload),
                }
            }
            EngineGetPayloadVersion::V3 => {
                let payload = engine.get_payload_v3(payload_id).await.map_err(|e| {
                    error!(target: "engine", error = %e, "Payload fetch failed");
                    SealTaskError::GetPayloadFailed(e)
                })?;

                BaseExecutionPayloadEnvelope {
                    parent_beacon_block_root: Some(payload.parent_beacon_block_root),
                    execution_payload: BaseExecutionPayload::V3(payload.execution_payload),
                }
            }
            EngineGetPayloadVersion::V2 => {
                let payload = engine.get_payload_v2(payload_id).await.map_err(|e| {
                    error!(target: "engine", error = %e, "Payload fetch failed");
                    SealTaskError::GetPayloadFailed(e)
                })?;

                BaseExecutionPayloadEnvelope {
                    parent_beacon_block_root: None,
                    execution_payload: match payload.execution_payload.into_payload() {
                        ExecutionPayload::V1(payload) => BaseExecutionPayload::V1(payload),
                        ExecutionPayload::V2(payload) => BaseExecutionPayload::V2(payload),
                        _ => unreachable!("the response should be a V1 or V2 payload"),
                    },
                }
            }
        };

        Ok(payload_envelope)
    }

    /// Inserts a payload into the engine with Holocene fallback support.
    ///
    /// This function handles:
    /// 1. Executing the `InsertTask` to import the payload
    /// 2. Handling deposits-only payload failures
    /// 3. Holocene fallback via `build_and_seal` if needed
    ///
    /// Returns Ok(()) if the payload is successfully inserted, or an error if insertion fails.
    async fn insert_payload(
        &self,
        state: &mut EngineState,
        new_payload: BaseExecutionPayloadEnvelope,
    ) -> Result<(), SealTaskError> {
        // Insert the new block into the engine.
        match InsertTask::new(
            Arc::clone(&self.engine),
            Arc::clone(&self.cfg),
            new_payload.clone(),
            self.is_attributes_derived,
        )
        .execute(state)
        .await
        {
            Err(InsertTaskError::UnexpectedPayloadStatus(e))
                if self.attributes.is_deposits_only() =>
            {
                error!(target: "engine", error = ?e, "Critical: Deposit-only payload import failed");
                return Err(SealTaskError::DepositOnlyPayloadFailed);
            }
            Err(InsertTaskError::UnexpectedPayloadStatus(e))
                if self.cfg.is_holocene_active(
                    self.attributes.attributes().payload_attributes.timestamp,
                ) =>
            {
                warn!(target: "engine", error = ?e, "Re-attempting payload import with deposits only.");

                // HOLOCENE: Re-attempt payload import with deposits only
                // First build the deposits-only payload, then seal it
                let deposits_only_attrs = self.attributes.as_deposits_only();

                return match build_and_seal(
                    state,
                    Arc::clone(&self.engine),
                    Arc::clone(&self.cfg),
                    deposits_only_attrs.clone(),
                    self.is_attributes_derived,
                )
                .await
                {
                    Ok(_) => {
                        info!(target: "engine", "Successfully imported deposits-only payload");
                        Err(SealTaskError::HoloceneInvalidFlush)
                    }
                    Err(_) => Err(SealTaskError::DepositOnlyPayloadReattemptFailed),
                };
            }
            Err(e) => {
                error!(target: "engine", error = %e, "Payload import failed");
                return Err(Box::new(e).into());
            }
            Ok(_) => {
                info!(target: "engine", "Successfully imported payload")
            }
        }

        Ok(())
    }

    /// Seals and canonicalizes the block by fetching the payload and importing it.
    ///
    /// This function handles:
    /// 1. Fetching the execution payload from the EL
    /// 2. Importing the payload into the engine with Holocene fallback support
    /// 3. Sending the payload to the optional channel
    async fn seal_and_canonicalize_block(
        &self,
        state: &mut EngineState,
    ) -> Result<BaseExecutionPayloadEnvelope, SealTaskError> {
        // Fetch the payload just inserted from the EL and import it into the engine.
        let block_import_start_time = Instant::now();
        let new_payload = self
            .seal_payload(&self.cfg, &self.engine, self.payload_id, self.attributes.clone())
            .await?;

        let new_block_ref = L2BlockInfo::from_payload_and_genesis(
            new_payload.execution_payload.clone(),
            self.attributes.attributes().payload_attributes.parent_beacon_block_root,
            &self.cfg.genesis,
        )
        .map_err(SealTaskError::FromBlock)?;

        // Insert the payload into the engine.
        self.insert_payload(state, new_payload.clone()).await?;

        let block_import_duration = block_import_start_time.elapsed();

        info!(
            target: "engine",
            l2_number = new_block_ref.block_info.number,
            l2_time = new_block_ref.block_info.timestamp,
            block_import_duration = ?block_import_duration,
            "Built and imported new {} block",
            if self.is_attributes_derived { "safe" } else { "unsafe" },
        );

        Ok(new_payload)
    }

    /// Sends the provided result via the `result_tx` sender if one exists, returning the
    /// appropriate error if it does not.
    ///
    /// This allows the original caller to handle errors, removing that burden from the engine,
    /// which may not know the caller's intent or retry preferences. If the original caller did not
    /// provide a mechanism to get notified of updates, handle the error in the default manner in
    /// the task queue logic.
    async fn send_channel_result_or_get_error(
        &self,
        res: Result<BaseExecutionPayloadEnvelope, SealTaskError>,
    ) -> Result<(), SealTaskError> {
        // NB: If a response channel was provided, that channel will receive success/failure info,
        // and this task will always succeed. If not, task failure will be relayed to the caller.
        if let Some(tx) = &self.result_tx {
            tx.send(res).await.map_err(|e| SealTaskError::MpscSend(Box::new(e)))?;
        } else if let Err(x) = res {
            return Err(x);
        }

        Ok(())
    }
}

#[async_trait]
impl<EngineClient_: EngineClient> EngineTaskExt for SealTask<EngineClient_> {
    type Output = ();

    type Error = SealTaskError;

    async fn execute(&self, state: &mut EngineState) -> Result<(), SealTaskError> {
        debug!(
            target: "engine",
            txs = self.attributes.attributes().transactions.as_ref().map_or(0, |txs| txs.len()),
            is_deposits = self.attributes.is_deposits_only(),
            "Starting new seal job"
        );

        // NOTE: the reference node does not compare the current unsafe head against the
        // attributes parent before sealing.  The BuildTask already sent an FCU
        // with `attributes.parent` as the head, so the EL is building on the
        // correct parent regardless of where the engine's in-memory unsafe head
        // sits.  During consolidation the safe head is intentionally behind the
        // unsafe head, so this comparison would always fail and previously caused
        // a fatal crash (Critical) or infinite reset loop (Reset).
        let res = self.seal_and_canonicalize_block(state).await;

        self.send_channel_result_or_get_error(res).await?;

        Ok(())
    }
}
