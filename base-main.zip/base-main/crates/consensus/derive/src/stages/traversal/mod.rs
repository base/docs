//! Contains various traversal stages for the derivation pipeline.
//!
//! The traversal stage sits at the bottom of the pipeline, and is responsible for
//! providing the next block to the next stage in the pipeline.
//!
//! ## Types
//!
//! - [`PollingTraversal`]: An active traversal stage that polls for the next block through its
//!   provider.

use alloy_consensus::Receipt;
use alloy_primitives::Address;
use base_common_genesis::SystemConfig;

use crate::Metrics;

mod polling;
pub use polling::PollingTraversal;

/// Updates the system config with receipts, logging each applied update and any errors,
/// and setting the appropriate metrics gauges.
fn update_system_config_with_receipts(
    system_config: &mut SystemConfig,
    receipts: &[Receipt],
    l1_system_config_address: Address,
    ecotone_active: bool,
    block_number: u64,
) {
    let (updates, errors) =
        system_config.update_with_receipts(receipts, l1_system_config_address, ecotone_active);
    for kind in &updates {
        info!(target: "traversal", %kind, block_number, "Applied system config update");
    }
    if !updates.is_empty() {
        Metrics::pipeline_latest_sys_config_update().set(block_number as f64);
    }
    for err in &errors {
        warn!(target: "traversal", error = ?err, block_number, "Malformed system config update (skipped)");
        Metrics::pipeline_sys_config_update_error().set(block_number as f64);
    }
}
