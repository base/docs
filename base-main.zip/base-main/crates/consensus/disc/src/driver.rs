//! Discovery Module.

use backon::{ExponentialBuilder, RetryableWithContext};
use base_consensus_peers::{
    BootNode, BootNodes, BootStore, BootStoreFile, EnrValidation, PeerUtils,
};
use derive_more::Debug;
use discv5::{Config, Discv5, Enr, enr::NodeId};
use tokio::{
    sync::mpsc::channel,
    time::{Duration, sleep},
};

use crate::{Discv5Builder, Discv5Handler, HandlerRequest, LocalNode, Metrics};

/// The [`Discv5Driver`] drives the discovery service.
///
/// Calling [`Discv5Driver::start`] spawns a new [`Discv5`]
/// discovery service in a new tokio task and returns a
/// [`Discv5Handler`].
///
/// Channels are used to communicate between the [`Discv5Handler`]
/// and the spawned task containing the [`Discv5`] service.
///
/// Since some requested operations are asynchronous, this pattern of message
/// passing is used as opposed to wrapping the [`Discv5`] in an `Arc<Mutex<>>`.
/// If an `Arc<Mutex<>>` were used, a lock held across the operation's future
/// would be needed since some asynchronous operations require a mutable
/// reference to the [`Discv5`] service.
#[derive(Debug)]
pub struct Discv5Driver {
    /// The [`Discv5`] discovery service.
    #[debug(skip)]
    pub disc: Discv5,
    /// The optional [`BootStoreFile`] to use for the bootstore.
    pub bootstore: Option<BootStoreFile>,
    /// Bootnodes used to bootstrap the discovery service.
    pub bootnodes: BootNodes,
    /// The chain ID of the network.
    pub chain_id: u64,
    /// The interval to discovery random nodes.
    pub interval: Duration,
    /// Whether to forward ENRs to the enr receiver on startup.
    pub forward: bool,
    /// The interval at which to store the ENRs in the bootstore.
    /// This is set to 60 seconds by default.
    pub store_interval: Duration,
    /// The frequency at which to remove random nodes from the discovery table.
    /// This is not enabled (`None`) by default.
    pub remove_interval: Option<Duration>,
}

impl Discv5Driver {
    /// Returns a new [`Discv5Builder`] instance.
    pub fn builder(
        local_node: LocalNode,
        chain_id: u64,
        discovery_config: Config,
    ) -> Discv5Builder {
        Discv5Builder::new(local_node, chain_id, discovery_config)
    }

    /// Instantiates a new [`Discv5Driver`].
    pub const fn new(
        disc: Discv5,
        interval: Duration,
        chain_id: u64,
        bootstore: Option<BootStoreFile>,
        bootnodes: BootNodes,
    ) -> Result<Self, std::io::Error> {
        Ok(Self {
            disc,
            chain_id,
            bootnodes,
            interval,
            forward: true,
            remove_interval: None,
            store_interval: Duration::from_secs(60),
            bootstore,
        })
    }

    /// Starts the inner [`Discv5`] service.
    async fn init(self) -> Result<Self, discv5::Error> {
        let (s, res) = {
            |mut v: Self| async {
                let res = v.disc.start().await;
                (v, res)
            }
        }
            .retry(ExponentialBuilder::default())
            .context(self)
            .notify(|err: &discv5::Error, dur: Duration| {
                warn!(target: "discovery", error = ?err, duration = ?dur, "Failed to start discovery service");
            })
            .await;
        res.map(|_| s)
    }

    /// Bootstraps the [`Discv5`] table with bootnodes.
    async fn bootstrap_peers(
        bootstore: Option<BootStoreFile>,
        bootnodes: BootNodes,
        chain_id: u64,
        disc: &Discv5,
    ) -> BootStore {
        // Note: if the bootstore file cannot be created, we use a default bootstore.
        let mut store = bootstore
            .map_or_else(BootStore::default, |bootstore| bootstore.try_into().unwrap_or_default());

        let initial_store_length = store.len();

        for bn in bootnodes.0.into_iter().chain(BootNodes::from_chain_id(chain_id).0.into_iter()) {
            let res = match bn {
                BootNode::Enr(enr) => Ok(enr.clone()),
                BootNode::Enode(enode) => disc.request_enr(enode.clone()).await,
            };

            let Ok(enr) = res else {
                debug!(target: "discovery::bootstrap", ?res, "Failed to add boot node ENR to discovery table");
                continue;
            };

            let validation = EnrValidation::validate(&enr, chain_id);
            if validation.is_invalid() {
                trace!(target: "discovery::bootstrap", enr = ?enr, validation = ?validation, "Ignoring Invalid Bootnode ENR");
                continue;
            }

            if let Err(e) = disc.add_enr(enr.clone()) {
                debug!(target: "discovery::bootstrap", error = ?e, "Failed to add enr");
                continue;
            }

            store.add_enr(enr);
        }

        let new_store_len = store.len();

        debug!(target: "discovery::bootstrap",
            added=%(new_store_len - initial_store_length),
            total=%new_store_len,
            "Added new ENRs to discv5 bootstore"
        );

        store
    }

    /// Spawns a new [`Discv5`] discovery service in a new tokio task.
    ///
    /// Returns a [`Discv5Handler`] to communicate with the spawned task.
    pub fn start(mut self) -> (Discv5Handler, tokio::sync::mpsc::Receiver<Enr>) {
        let chain_id = self.chain_id;
        let (req_sender, mut req_recv) = channel::<HandlerRequest>(1024);
        let (enr_sender, enr_recv) = channel::<Enr>(1024);

        tokio::spawn(async move {
            let remove = self.remove_interval.is_some();
            let remove_dur = self.remove_interval.unwrap_or(std::time::Duration::from_secs(600));
            let mut removal_interval = tokio::time::interval(remove_dur);
            let mut interval = tokio::time::interval(self.interval);
            let mut store_interval = tokio::time::interval(self.store_interval);

            // Step 1: Start the discovery service.
            let Ok(s) = self.init().await else {
                error!(target: "discovery", "Failed to start discovery service");
                return;
            };
            self = s;
            trace!(target: "discovery", "Discv5 Initialized");

            // Step 2: Bootstrap the discovery table with bootnodes.
            let mut store =
                Self::bootstrap_peers(self.bootstore, self.bootnodes, chain_id, &self.disc).await;

            let enrs = self.disc.table_entries_enr();
            info!(target: "discovery", count = enrs.len(), "Discv5 Started");

            // Step 3: Forward ENRs in the bootstore to the enr receiver.
            if self.forward {
                for enr in store.valid_peers_with_chain_id(self.chain_id) {
                    if let Err(e) = enr_sender.send(enr.clone()).await {
                        debug!(target: "discovery", error = ?e, "Failed to forward enr");
                    }
                }
            }

            // Continuously attempt to start the event stream with a retry limit and shutdown
            // signal.
            let mut retries = 0;
            let max_retries = 10; // Maximum number of retries before giving up.
            let mut event_stream = loop {
                if retries >= max_retries {
                    error!(target: "discovery", "Exceeded maximum retries for event stream startup. Aborting...");
                    return; // Exit the task if the retry limit is reached.
                }
                match self.disc.event_stream().await {
                    Ok(event_stream) => {
                        break event_stream;
                    }
                    Err(e) => {
                        warn!(target: "discovery", error = ?e, "Failed to start event stream");
                        retries += 1;
                        sleep(Duration::from_secs(2)).await;
                        info!(target: "discovery", attempt = retries, max = max_retries, "Retrying event stream startup");
                    }
                }
            };

            // Step 4: Run the core driver loop.
            loop {
                tokio::select! {
                    msg = req_recv.recv() => {
                        match msg {
                            Some(msg) => match msg {
                                HandlerRequest::Metrics(tx) => {
                                    let metrics = self.disc.metrics();
                                    if let Err(e) = tx.send(metrics) {
                                        warn!(target: "discovery", error = ?e, "Failed to send metrics");
                                    }
                                }
                                HandlerRequest::PeerCount(tx) => {
                                    let peers = self.disc.connected_peers();
                                    if let Err(e) = tx.send(peers) {
                                        warn!(target: "discovery", error = ?e, "Failed to send peer count");
                                    }
                                }
                                HandlerRequest::LocalEnr(tx) => {
                                    let enr = self.disc.local_enr().clone();
                                    if let Err(e) = tx.send(enr.clone()) {
                                        warn!(target: "discovery", error = ?e, "Failed to send local enr");
                                    }
                                }
                                HandlerRequest::AddEnr(enr) => {
                                    let _ = self.disc.add_enr(enr);
                                }
                                HandlerRequest::RequestEnr{out, addr} => {
                                    let enr = self.disc.request_enr(addr).await;
                                    if let Err(e) = out.send(enr) {
                                        warn!(target: "discovery", error = ?e, "Failed to send request enr");
                                    }
                                }
                                HandlerRequest::TableEnrs(tx) => {
                                    let enrs = self.disc.table_entries_enr();
                                    if let Err(e) = tx.send(enrs) {
                                        warn!(target: "discovery", error = ?e, "Failed to send table enrs");
                                    }
                                },
                                HandlerRequest::TableInfos(tx) => {
                                    let infos = self.disc.table_entries();
                                    if let Err(e) = tx.send(infos) {
                                        warn!(target: "discovery", error = ?e, "Failed to send table infos");
                                    }
                                },
                                HandlerRequest::BanAddrs{addrs_to_ban, ban_duration} => {
                                    let enrs = self.disc.table_entries_enr();

                                    for enr in enrs {
                                        let Some(multi_addr) = PeerUtils::enr_to_multiaddr(&enr) else {
                                            continue;
                                        };

                                        if addrs_to_ban.contains(&multi_addr) {
                                            self.disc.ban_node(&enr.node_id(), Some(ban_duration));
                                        }
                                    }
                                },
                            }
                            None => {
                                trace!(target: "discovery", "Receiver `None` peer enr");
                            }
                        }
                    }
                    event = event_stream.recv() => {
                        let Some(event) = event else {
                            trace!(target: "discovery", "Received `None` event");
                            continue;
                        };
                        match event {
                            discv5::Event::Discovered(enr) => {
                                if EnrValidation::validate(&enr, chain_id).is_valid() {
                                    debug!(target: "discovery", enr = ?enr, "Valid ENR discovered, forwarding to swarm");
                                    Metrics::discovery_event("discovered").increment(1.0);
                                    store.add_enr(enr.clone());
                                    let sender = enr_sender.clone();
                                    tokio::spawn(async move {
                                        if let Err(e) = sender.send(enr).await {
                                            debug!(target: "discovery", error = ?e, "Failed to send enr");
                                        }
                                    });
                                }
                            }
                            discv5::Event::SessionEstablished(enr, addr) => {
                                if EnrValidation::validate(&enr, chain_id).is_valid() {
                                    debug!(target: "discovery", addr = ?addr, enr = ?enr, "Session established with valid ENR, forwarding to swarm");
                                    Metrics::discovery_event("session_established").increment(1.0);
                                    store.add_enr(enr.clone());
                                    let sender = enr_sender.clone();
                                    tokio::spawn(async move {
                                        if let Err(e) = sender.send(enr).await {
                                            debug!(target: "discovery", error = ?e, "Failed to send enr");
                                        }
                                    });
                                }
                            }
                            discv5::Event::UnverifiableEnr { enr, .. } => {
                                if EnrValidation::validate(&enr, chain_id).is_valid() {
                                    debug!(target: "discovery", enr = ?enr, "Valid ENR discovered, forwarding to swarm");
                                    Metrics::discovery_event("unverifiable_enr").increment(1.0);
                                    store.add_enr(enr.clone());
                                    let sender = enr_sender.clone();
                                    tokio::spawn(async move {
                                        if let Err(e) = sender.send(enr).await {
                                            debug!(target: "discovery", error = ?e, "Failed to send enr");
                                        }
                                    });
                                }

                            }
                            _ => {}
                        }
                    }
                    _ = interval.tick() => {
                        let id = NodeId::random();
                        trace!(target: "discovery", node_id = %id, "Finding random node");
                        Metrics::find_node_request().increment(1.0);
                        let fut = self.disc.find_node(id);
                        let enr_sender = enr_sender.clone();
                        tokio::spawn(async move {
                            match fut.await {
                                Ok(nodes) => {
                                    let enrs = nodes.into_iter().filter(|node| EnrValidation::validate(node, chain_id).is_valid());
                                    for enr in enrs {
                                        _ = enr_sender.send(enr).await;
                                    }
                                }
                                Err(err) => {
                                    info!(target: "discovery", error = ?err, "Failed to find node");
                                }
                            }
                        });
                    }
                    _ = store_interval.tick() => {
                        let start = std::time::Instant::now();
                        let enrs = self.disc.table_entries_enr();
                        store.merge(enrs);

                        if let Err(e) = store.sync() {
                            warn!(target: "discovery", error = ?e, "Failed to sync bootstore");
                        }

                        let elapsed = start.elapsed();
                        debug!(target: "discovery", elapsed = ?elapsed, "Bootstore ENRs stored");
                        Metrics::enr_store_time().record(elapsed.as_secs_f64());
                        Metrics::discovery_peer_count().set(self.disc.connected_peers() as f64);
                    }
                    _ = removal_interval.tick() => {
                        if remove {
                            let enrs = self.disc.table_entries_enr();
                            if enrs.len() > 20 {
                                let mut rng = rand::rng();
                                let index = rand::Rng::random_range(&mut rng, 0..enrs.len());
                                let enr = enrs[index].clone();
                                debug!(target: "removal", enr = ?enr, "Removing random ENR");
                                self.disc.remove_node(&enr.node_id());
                            }
                        }
                    }
                }
            }
        });

        (Discv5Handler::new(chain_id, req_sender), enr_recv)
    }
}

#[cfg(test)]
mod tests {
    use std::net::{IpAddr, Ipv4Addr, SocketAddr};

    use base_common_chains::ChainConfig;
    use discv5::{
        ConfigBuilder,
        enr::{CombinedKey, CombinedPublicKey},
        handler::NodeContact,
    };
    use tempfile::tempdir;

    use super::*;
    use crate::LocalNode;

    #[tokio::test]
    async fn test_online_discv5_driver() {
        let CombinedKey::Secp256k1(secret_key) = CombinedKey::generate_secp256k1() else {
            unreachable!()
        };

        let socket = SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0);
        let discovery = Discv5Driver::builder(
            LocalNode::new(secret_key, IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0, 0),
            ChainConfig::sepolia().chain_id,
            ConfigBuilder::new(socket.into()).build(),
        )
        .build()
        .expect("Failed to build discovery service");
        let (handle, _) = discovery.start();
        assert_eq!(handle.chain_id, ChainConfig::sepolia().chain_id);
    }

    #[tokio::test]
    async fn test_online_discv5_driver_bootstrap_testnet() {
        // Use a test file to make sure bootstore
        // doesn't conflict with a local bootstore.
        let file = tempdir().unwrap();
        let file = file.path().join("bootstore.json");

        let socket = SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0);
        let CombinedKey::Secp256k1(secret_key) = CombinedKey::generate_secp256k1() else {
            unreachable!()
        };
        let mut discovery = Discv5Driver::builder(
            LocalNode::new(secret_key, IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0, 0),
            ChainConfig::sepolia().chain_id,
            ConfigBuilder::new(socket.into()).build(),
        )
        .with_bootnodes(BootNodes::testnet())
        .build()
        .expect("Failed to build discovery service");
        discovery.bootstore = Some(BootStoreFile::Custom(file));

        discovery = discovery.init().await.expect("Failed to initialize discovery service");

        // There are no ENRs for Base Sepolia in the bootstore.
        // If an ENR is added, this check will fail.
        Discv5Driver::bootstrap_peers(
            discovery.bootstore,
            discovery.bootnodes,
            ChainConfig::sepolia().chain_id,
            &discovery.disc,
        )
        .await;
        let enrs = discovery.disc.table_entries_enr();
        assert!(enrs.len() >= 2, "Discovery table should have at least 2 ENRs");

        // Filter out testnet ENRs that are not valid.
        let testnet = BootNodes::testnet();
        let testnet: Vec<CombinedPublicKey> = testnet
            .iter()
            .filter_map(|node| match node {
                BootNode::Enr(enr) => {
                    if EnrValidation::validate(enr, ChainConfig::sepolia().chain_id).is_invalid() {
                        return None;
                    }
                    Some(enr.public_key())
                }
                BootNode::Enode(_) => {
                    let node_contact =
                        NodeContact::try_from_multiaddr(node.to_multiaddr().unwrap()).unwrap();
                    Some(node_contact.public_key())
                }
            })
            .collect();

        // There should be 6 valid boot nodes for the testnet:
        // 2 ENRs + 4 enodes (each enode listed on ports 30301 and 9200).
        assert_eq!(testnet.len(), 6);

        // Those ENRs should be in the testnet bootnodes.
        for enr in &enrs {
            assert!(
                testnet.iter().any(|pub_key| pub_key == &enr.public_key()),
                "Discovery table does not contain testnet ENR: {enr:?}"
            );
        }
    }

    #[tokio::test]
    async fn test_online_discv5_driver_bootstrap_mainnet() {
        base_cli_utils::init_test_tracing();

        // Use a test file to make sure bootstore
        // doesn't conflict with a local bootstore.
        let file = tempdir().unwrap();
        let file = file.path().join("bootstore.json");

        // Filter out ENRs that are not valid.
        let mainnet = BootNodes::mainnet();
        let mainnet: Vec<CombinedPublicKey> = mainnet
            .iter()
            .filter_map(|node| match node {
                BootNode::Enr(enr) => {
                    if EnrValidation::validate(enr, ChainConfig::mainnet().chain_id).is_invalid() {
                        return None;
                    }
                    Some(enr.public_key())
                }
                BootNode::Enode(_) => {
                    let node_contact =
                        NodeContact::try_from_multiaddr(node.to_multiaddr().unwrap()).unwrap();
                    Some(node_contact.public_key())
                }
            })
            .collect();

        // There should be 15 valid boot nodes for the mainnet:
        // 5 Base Mainnet ENRs + 10 Base enodes (each enode listed on ports 30301 and 9200).
        assert_eq!(mainnet.len(), 15);

        let socket = SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0);

        let CombinedKey::Secp256k1(secret_key) = CombinedKey::generate_secp256k1() else {
            unreachable!()
        };

        let mut discovery = Discv5Driver::builder(
            LocalNode::new(secret_key, IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0, 0),
            ChainConfig::mainnet().chain_id,
            ConfigBuilder::new(socket.into()).build(),
        )
        .with_bootnodes(BootNodes::mainnet())
        .build()
        .expect("Failed to build discovery service");
        discovery.bootstore = Some(BootStoreFile::Custom(file));

        discovery = discovery.init().await.expect("Failed to initialize discovery service");

        // There are no ENRs for op mainnet in the bootstore.
        // If an ENR is added, this check will fail.
        Discv5Driver::bootstrap_peers(
            discovery.bootstore,
            discovery.bootnodes,
            ChainConfig::mainnet().chain_id,
            &discovery.disc,
        )
        .await;
        assert!(
            discovery.disc.table_entries_enr().len() >= 10,
            "Discovery table should have at least 10 ENRs"
        );

        // Those ENRs should be in the mainnet bootnodes.
        let disc_enrs = discovery.disc.table_entries_enr();
        for enr in disc_enrs {
            assert!(
                mainnet.iter().any(|pub_key| pub_key == &enr.public_key()),
                "Discovery table does not contain mainnet ENR: {enr:?}"
            );
        }
    }
}
