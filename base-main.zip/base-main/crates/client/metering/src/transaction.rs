use alloy_consensus::{Transaction, transaction::Recovered};
use alloy_eips::Encodable2718;
use alloy_primitives::U256;
use base_common_evm::{L1BlockInfo, OpSpecId};
use derive_more::Display;
use reth_primitives_traits::Account;

/// Errors that can occur when validating a transaction.
#[derive(Debug, PartialEq, Eq, Display)]
pub enum TxValidationError {
    /// Insufficient funds for transfer
    #[display("Insufficient funds for transfer: {_0}, account balance: {_1}")]
    InsufficientFundsForTransfer(U256, U256),
    /// Insufficient funds for L1 gas
    #[display("Insufficient funds for L1 gas: {_0}, account balance: {_1}")]
    InsufficientFundsForL1Gas(U256, U256),
}

/// Helper function to validate a transaction.
///
/// A valid transaction must satisfy the following criteria:
/// - The transaction's execution cost is less than the account's balance
/// - The transaction's L1 gas cost is less than the account's balance
///
/// Note: We don't need to check for EIP-4844 because bundle transactions are Recovered<BaseTxEnvelope>
/// which only includes Legacy, Eip2930, Eip1559, Eip7702, and Deposit.
pub fn validate_tx<T: Transaction + Encodable2718>(
    account: Account,
    txn: &Recovered<T>,
    l1_block_info: &mut L1BlockInfo,
) -> Result<(), TxValidationError> {
    let data = txn.encoded_2718();

    // For EIP-1559 transactions: `max_fee_per_gas * gas_limit + tx_value`.
    let max_fee = txn.max_fee_per_gas().saturating_mul(txn.gas_limit() as u128);
    let txn_cost = txn.value().saturating_add(U256::from(max_fee));

    // Return error if execution cost exceeds balance
    if txn_cost > account.balance {
        return Err(TxValidationError::InsufficientFundsForTransfer(txn_cost, account.balance));
    }

    // Base-specific checks to see whether the sender can cover the L1 gas cost.
    // Reference: https://github.com/paradigmxyz/reth/blob/6aa73f14808491aae77fc7c6eb4f0aa63bef7e6e/crates/optimism/txpool/src/validator.rs#L219
    let l1_cost_addition = l1_block_info.calculate_tx_l1_cost(&data, OpSpecId::ISTHMUS);
    let l1_cost = txn_cost.saturating_add(l1_cost_addition);
    if l1_cost > account.balance {
        return Err(TxValidationError::InsufficientFundsForL1Gas(l1_cost, account.balance));
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use alloy_consensus::{
        SignableTransaction, Transaction, TxEip1559, transaction::SignerRecoverable,
    };
    use alloy_network::TxSignerSync;
    use alloy_primitives::{Address, U256, bytes};
    use base_common_consensus::BaseTxEnvelope;
    use base_test_utils::Account as BaseAccount;

    use super::*;

    fn create_account(nonce: u64, balance: U256) -> Account {
        Account { balance, nonce, bytecode_hash: None }
    }

    fn create_l1_block_info() -> L1BlockInfo {
        L1BlockInfo::default()
    }

    #[test]
    fn test_err_tx_insufficient_funds() {
        let signer = BaseAccount::Alice.signer();
        let mut tx = TxEip1559 {
            chain_id: 1,
            nonce: 0,
            gas_limit: 21000,
            max_fee_per_gas: 20000000000u128,
            max_priority_fee_per_gas: 10000000000000u128,
            to: Address::random().into(),
            value: U256::from(10000000000000u128),
            access_list: Default::default(),
            input: bytes!(""),
        };

        let account_balance = U256::from(1000000u128);
        let account = create_account(0, account_balance);
        let mut l1_block_info = create_l1_block_info();

        let max_fee = tx.max_fee_per_gas().saturating_mul(tx.gas_limit() as u128);
        let txn_cost = tx.value().saturating_add(U256::from(max_fee));

        let signature = signer.sign_transaction_sync(&mut tx).unwrap();
        let envelope = BaseTxEnvelope::Eip1559(tx.into_signed(signature));
        let recovered_tx = envelope.try_into_recovered().unwrap();
        assert_eq!(
            validate_tx(account, &recovered_tx, &mut l1_block_info),
            Err(TxValidationError::InsufficientFundsForTransfer(txn_cost, account_balance))
        );
    }

    #[test]
    fn test_err_tx_insufficient_funds_for_l1_gas() {
        let signer = BaseAccount::Alice.signer();
        let mut tx = TxEip1559 {
            chain_id: 1,
            nonce: 0,
            gas_limit: 21000,
            max_fee_per_gas: 200000u128,
            max_priority_fee_per_gas: 100000u128,
            to: Address::random().into(),
            value: U256::from(1000000u128),
            access_list: Default::default(),
            input: bytes!(""),
        };

        // fund the account with enough funds to cover the txn cost but not enough to cover the l1 cost
        let account_balance = U256::from(4201000000u128);
        let account = create_account(0, account_balance);
        let mut l1_block_info = create_l1_block_info();
        l1_block_info.tx_l1_cost = Some(U256::from(1000000u128));

        let max_fee = tx.max_fee_per_gas().saturating_mul(tx.gas_limit() as u128);
        let txn_cost = tx.value().saturating_add(U256::from(max_fee));
        let l1_cost_addition = l1_block_info.calculate_tx_l1_cost(tx.input(), OpSpecId::ISTHMUS);
        let l1_cost = txn_cost.saturating_add(l1_cost_addition);

        let signature = signer.sign_transaction_sync(&mut tx).unwrap();
        let envelope = BaseTxEnvelope::Eip1559(tx.into_signed(signature));
        let recovered_tx = envelope.try_into_recovered().unwrap();

        assert_eq!(
            validate_tx(account, &recovered_tx, &mut l1_block_info),
            Err(TxValidationError::InsufficientFundsForL1Gas(l1_cost, account_balance))
        );
    }

    #[test]
    fn test_valid_tx() {
        let signer = BaseAccount::Alice.signer();
        let mut tx = TxEip1559 {
            chain_id: 1,
            nonce: 0,
            gas_limit: 21000,
            max_fee_per_gas: 20000000000u128,
            max_priority_fee_per_gas: 10000000000000u128,
            to: Address::random().into(),
            value: U256::from(10000000000000u128),
            access_list: Default::default(),
            input: bytes!(""),
        };

        let account_balance = U256::from(1000000000000000000u128);
        let account = create_account(0, account_balance);
        let mut l1_block_info = create_l1_block_info();

        let signature = signer.sign_transaction_sync(&mut tx).unwrap();
        let envelope = BaseTxEnvelope::Eip1559(tx.into_signed(signature));
        let recovered_tx = envelope.try_into_recovered().unwrap();

        assert_eq!(validate_tx(account, &recovered_tx, &mut l1_block_info), Ok(()));
    }
}
