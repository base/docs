//! Contains the [`MeteringExtension`] which wires up the metering RPC surface
//! on the Base node builder.

use std::{num::NonZeroUsize, sync::Arc};

use alloy_primitives::U256;
use base_flashblocks::{FlashblocksAPI, FlashblocksConfig, FlashblocksState};
use base_node_runner::{BaseNodeExtension, FromExtensionConfig, NodeHooks};
use parking_lot::RwLock;
use tracing::{debug, info, warn};

use crate::{
    DEFAULT_PENDING_STATE_ROOT_TIMES_CAPACITY, MeteredOpcodes, MeteringApiImpl, MeteringApiServer,
    MeteringCache, MeteringCollector, PendingStateRootTimes, PriorityFeeEstimator, ResourceLimits,
    estimator::assert_valid_percentile,
};

const TARGET_FLASHBLOCKS_PER_BLOCK_NON_ZERO_MSG: &str =
    "target_flashblocks_per_block must be greater than 0";
const CACHE_SIZE_NON_ZERO_MSG: &str = "cache_size must be greater than 0";

/// Resource limits configuration for priority fee estimation.
#[derive(Debug, Clone, Default)]
pub struct MeteringResourceLimits {
    /// Total gas budget for the block.
    ///
    /// The estimator mirrors the builder's flashblock loop and converts this into
    /// cumulative per-flashblock gas targets.
    pub gas_limit: Option<u64>,
    /// Execution time budget per flashblock in microseconds.
    ///
    /// This matches the builder's flashblock execution budget, which resets each
    /// flashblock instead of accumulating across the block.
    pub execution_time_us: Option<u64>,
    /// Total state root computation budget for the block in microseconds.
    ///
    /// Like the builder, the estimator treats this as a cumulative budget that
    /// later flashblocks can consume if earlier ones underuse it.
    pub state_root_time_us: Option<u64>,
    /// Total data-availability byte budget for the block.
    pub da_bytes: Option<u64>,
}

impl MeteringResourceLimits {
    /// Converts to the internal [`ResourceLimits`] type.
    pub fn to_resource_limits(&self) -> ResourceLimits {
        ResourceLimits {
            gas_used: self.gas_limit,
            execution_time_us: self.execution_time_us.map(|v| v as u128),
            state_root_time_us: self.state_root_time_us.map(|v| v as u128),
            data_availability_bytes: self.da_bytes,
        }
    }

    /// Returns true if any resource uses the builder's cumulative multi-flashblock budget.
    const fn uses_accumulating_resource_limits(&self) -> bool {
        self.gas_limit.is_some() || self.state_root_time_us.is_some() || self.da_bytes.is_some()
    }
}

/// Helper struct that wires the metering RPC into the node builder.
#[derive(Debug)]
pub struct MeteringExtension {
    /// Whether metering is enabled.
    pub enabled: bool,
    /// Optional Flashblocks configuration (includes state).
    pub flashblocks_config: Option<FlashblocksConfig>,
    /// Resource limits for priority fee estimation.
    pub resource_limits: MeteringResourceLimits,
    /// Percentile for priority fee estimation (e.g., 0.5 for median).
    pub priority_fee_percentile: f64,
    /// Default priority fee when resources are uncongested (in wei).
    pub uncongested_priority_fee: u64,
    /// Number of blocks to retain in the metering cache.
    ///
    /// Must be greater than zero when set on an estimator-enabled configuration.
    pub cache_size: usize,
    /// Target number of tx-pool flashblocks the builder budgets each block against.
    ///
    /// This excludes the initial base flashblock at index `0`.
    /// Must be greater than zero when set. Required when gas, state root time,
    /// or DA priority fee estimation is enabled.
    pub target_flashblocks_per_block: Option<usize>,
    /// Opcodes and precompiles to track for gas metering.
    pub metered_opcodes: MeteredOpcodes,
}

impl Default for MeteringExtension {
    fn default() -> Self {
        Self {
            enabled: false,
            flashblocks_config: None,
            resource_limits: MeteringResourceLimits::default(),
            priority_fee_percentile: 0.5,
            uncongested_priority_fee: 1_000_000,
            cache_size: 12,
            target_flashblocks_per_block: None,
            metered_opcodes: MeteredOpcodes::default(),
        }
    }
}

impl MeteringExtension {
    /// Creates a new metering extension.
    pub fn new(enabled: bool, flashblocks_config: Option<FlashblocksConfig>) -> Self {
        Self {
            enabled,
            flashblocks_config,
            resource_limits: MeteringResourceLimits {
                gas_limit: None,
                execution_time_us: None,
                state_root_time_us: None,
                da_bytes: None,
            },
            priority_fee_percentile: 0.5,
            uncongested_priority_fee: 1_000_000,
            cache_size: 12,
            target_flashblocks_per_block: None,
            metered_opcodes: MeteredOpcodes::default(),
        }
    }

    /// Sets the resource limits.
    pub const fn with_resource_limits(mut self, limits: MeteringResourceLimits) -> Self {
        self.resource_limits = limits;
        self
    }

    /// Sets the priority fee percentile.
    pub const fn with_percentile(mut self, percentile: f64) -> Self {
        assert_valid_percentile(percentile);
        self.priority_fee_percentile = percentile;
        self
    }

    /// Sets the uncongested priority fee.
    pub const fn with_uncongested_fee(mut self, fee: u64) -> Self {
        self.uncongested_priority_fee = fee;
        self
    }

    /// Sets the cache size.
    pub const fn with_cache_size(mut self, size: usize) -> Self {
        self.cache_size = size;
        self
    }

    /// Sets the target number of tx-pool flashblocks the builder budgets per block.
    pub const fn with_target_flashblocks_per_block(mut self, count: usize) -> Self {
        self.target_flashblocks_per_block = Some(count);
        self
    }

    /// Sets the opcodes and precompiles to track for gas metering.
    pub fn with_metered_opcodes(mut self, opcodes: MeteredOpcodes) -> Self {
        self.metered_opcodes = opcodes;
        self
    }

    /// Returns true if priority fee estimation is configured (has resource limits).
    const fn has_estimator_config(&self) -> bool {
        self.resource_limits.gas_limit.is_some()
            || self.resource_limits.execution_time_us.is_some()
            || self.resource_limits.state_root_time_us.is_some()
            || self.resource_limits.da_bytes.is_some()
    }

    const fn resolved_cache_size(&self) -> usize {
        NonZeroUsize::new(self.cache_size).expect(CACHE_SIZE_NON_ZERO_MSG).get()
    }

    const fn resolved_target_flashblocks_per_block(
        &self,
        requires_target_flashblocks: bool,
    ) -> usize {
        match self.target_flashblocks_per_block {
            Some(count) => {
                NonZeroUsize::new(count).expect(TARGET_FLASHBLOCKS_PER_BLOCK_NON_ZERO_MSG).get()
            }
            None if requires_target_flashblocks => {
                panic!(
                    "target_flashblocks_per_block must be configured when gas, state root time, or data availability priority fee estimation is enabled"
                )
            }
            None => 1,
        }
    }
}

impl BaseNodeExtension for MeteringExtension {
    /// Applies the extension to the supplied hooks.
    fn apply(self: Box<Self>, hooks: NodeHooks) -> NodeHooks {
        if !self.enabled {
            return hooks;
        }

        let has_estimator = self.has_estimator_config();
        let requires_target_flashblocks = self.resource_limits.uses_accumulating_resource_limits();
        let resource_limits = self.resource_limits.to_resource_limits();
        let percentile = self.priority_fee_percentile;
        let default_fee = U256::from(self.uncongested_priority_fee);
        let cache_size = has_estimator.then(|| self.resolved_cache_size());
        let target_flashblocks_per_block = has_estimator
            .then(|| self.resolved_target_flashblocks_per_block(requires_target_flashblocks));
        let flashblocks_config = self.flashblocks_config;
        let metered_opcodes = Arc::new(self.metered_opcodes);

        hooks.add_rpc_module(move |ctx| {
            let fb_state: Arc<FlashblocksState> =
                flashblocks_config.as_ref().map(|cfg| Arc::clone(&cfg.state)).unwrap_or_default();

            let metering_api = if has_estimator {
                let cache_size = cache_size.expect("estimator configuration validated");
                let target_flashblocks_per_block =
                    target_flashblocks_per_block.expect("estimator configuration validated");

                info!(
                    message = "Starting Metering RPC with priority fee estimation",
                    cache_size = cache_size,
                    percentile = percentile,
                    target_flashblocks_per_block = target_flashblocks_per_block,
                );

                let cache = Arc::new(RwLock::new(MeteringCache::new(
                    cache_size,
                    target_flashblocks_per_block + 1,
                )));
                let estimator = Arc::new(PriorityFeeEstimator::new(
                    Arc::clone(&cache),
                    percentile,
                    resource_limits,
                    default_fee,
                    target_flashblocks_per_block,
                ));

                let state_root_cache = Arc::new(RwLock::new(PendingStateRootTimes::new(
                    NonZeroUsize::new(DEFAULT_PENDING_STATE_ROOT_TIMES_CAPACITY)
                        .expect("pending state root time cache capacity must be greater than 0"),
                )));

                // Spawn the metering collector if flashblocks are configured
                if let Some(ref cfg) = flashblocks_config {
                    let flashblock_rx = cfg.state.subscribe_to_flashblocks();
                    let collector = MeteringCollector::new(
                        Arc::clone(&cache),
                        Arc::clone(&state_root_cache),
                        flashblock_rx,
                    );
                    let collector_handle = tokio::spawn(collector.run());
                    tokio::spawn(async move {
                        match collector_handle.await {
                            Ok(()) => debug!("metering collector task exited"),
                            Err(error) if error.is_cancelled() => {
                                debug!(error = %error, "metering collector task cancelled")
                            }
                            Err(error) => {
                                warn!(error = %error, "metering collector task exited unexpectedly")
                            }
                        }
                    });
                }

                MeteringApiImpl::with_estimator(
                    ctx.provider().clone(),
                    fb_state,
                    estimator,
                    state_root_cache,
                    Arc::clone(&metered_opcodes),
                )
            } else {
                info!(message = "Starting Metering RPC (priority fee estimation disabled)");
                MeteringApiImpl::new(ctx.provider().clone(), fb_state, Arc::clone(&metered_opcodes))
            };

            ctx.modules.merge_configured(metering_api.into_rpc())?;

            Ok(())
        })
    }
}

/// Configuration for building a [`MeteringExtension`].
#[derive(Debug)]
pub struct MeteringConfig {
    /// Whether metering is enabled.
    pub enabled: bool,
    /// Optional Flashblocks configuration (includes state).
    pub flashblocks_config: Option<FlashblocksConfig>,
    /// Resource limits for priority fee estimation.
    pub resource_limits: MeteringResourceLimits,
    /// Percentile for priority fee estimation.
    pub priority_fee_percentile: f64,
    /// Default priority fee when uncongested.
    pub uncongested_priority_fee: u64,
    /// Number of blocks to retain in the metering cache.
    ///
    /// Must be greater than zero when used for priority fee estimation.
    pub cache_size: usize,
    /// Target number of tx-pool flashblocks the builder budgets per block.
    ///
    /// Must be greater than zero when set. Required when gas, state root time,
    /// or DA priority fee estimation is enabled.
    pub target_flashblocks_per_block: Option<usize>,
    /// Opcodes and precompiles to track for gas metering.
    pub metered_opcodes: MeteredOpcodes,
}

impl MeteringConfig {
    /// Creates a configuration with metering disabled.
    pub fn disabled() -> Self {
        Self { enabled: false, ..Self::enabled() }
    }

    /// Creates a configuration with metering enabled and no flashblocks integration.
    pub fn enabled() -> Self {
        Self {
            enabled: true,
            flashblocks_config: None,
            resource_limits: MeteringResourceLimits {
                gas_limit: None,
                execution_time_us: None,
                state_root_time_us: None,
                da_bytes: None,
            },
            priority_fee_percentile: 0.5,
            uncongested_priority_fee: 1_000_000,
            cache_size: 12,
            target_flashblocks_per_block: None,
            metered_opcodes: MeteredOpcodes::default(),
        }
    }

    /// Creates a configuration with metering enabled and flashblocks integration.
    pub fn with_flashblocks(flashblocks_config: FlashblocksConfig) -> Self {
        Self {
            enabled: true,
            flashblocks_config: Some(flashblocks_config),
            resource_limits: MeteringResourceLimits {
                gas_limit: None,
                execution_time_us: None,
                state_root_time_us: None,
                da_bytes: None,
            },
            priority_fee_percentile: 0.5,
            uncongested_priority_fee: 1_000_000,
            cache_size: 12,
            target_flashblocks_per_block: None,
            metered_opcodes: MeteredOpcodes::default(),
        }
    }

    /// Sets the resource limits.
    pub const fn with_resource_limits(mut self, limits: MeteringResourceLimits) -> Self {
        self.resource_limits = limits;
        self
    }

    /// Sets the priority fee percentile.
    pub const fn with_percentile(mut self, percentile: f64) -> Self {
        assert_valid_percentile(percentile);
        self.priority_fee_percentile = percentile;
        self
    }

    /// Sets the uncongested priority fee.
    pub const fn with_uncongested_fee(mut self, fee: u64) -> Self {
        self.uncongested_priority_fee = fee;
        self
    }

    /// Sets the cache size.
    pub const fn with_cache_size(mut self, size: usize) -> Self {
        self.cache_size = size;
        self
    }

    /// Sets the target number of tx-pool flashblocks the builder budgets per block.
    pub const fn with_target_flashblocks_per_block(mut self, count: usize) -> Self {
        self.target_flashblocks_per_block = Some(count);
        self
    }

    /// Sets the opcodes and precompiles to track for gas metering.
    pub fn with_metered_opcodes(mut self, opcodes: MeteredOpcodes) -> Self {
        self.metered_opcodes = opcodes;
        self
    }
}

impl FromExtensionConfig for MeteringExtension {
    type Config = MeteringConfig;

    fn from_config(config: Self::Config) -> Self {
        assert_valid_percentile(config.priority_fee_percentile);
        Self {
            enabled: config.enabled,
            flashblocks_config: config.flashblocks_config,
            resource_limits: config.resource_limits,
            priority_fee_percentile: config.priority_fee_percentile,
            uncongested_priority_fee: config.uncongested_priority_fee,
            cache_size: config.cache_size,
            target_flashblocks_per_block: config.target_flashblocks_per_block,
            metered_opcodes: config.metered_opcodes,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn resolves_default_target_flashblocks_when_optional() {
        let extension = MeteringExtension::default();

        assert_eq!(extension.resolved_target_flashblocks_per_block(false), 1);
    }

    #[test]
    fn resolves_configured_target_flashblocks() {
        let extension = MeteringExtension::default().with_target_flashblocks_per_block(4);

        assert_eq!(extension.resolved_target_flashblocks_per_block(true), 4);
    }

    #[test]
    #[should_panic(
        expected = "target_flashblocks_per_block must be configured when gas, state root time, or data availability priority fee estimation is enabled"
    )]
    fn missing_required_target_flashblocks_panics() {
        let extension = MeteringExtension::default();

        let _ = extension.resolved_target_flashblocks_per_block(true);
    }

    #[test]
    #[should_panic(expected = "target_flashblocks_per_block must be greater than 0")]
    fn zero_target_flashblocks_panics() {
        let extension = MeteringExtension::default().with_target_flashblocks_per_block(0);

        let _ = extension.resolved_target_flashblocks_per_block(false);
    }

    #[test]
    #[should_panic(expected = "cache_size must be greater than 0")]
    fn zero_cache_size_panics() {
        let extension = MeteringExtension::default().with_cache_size(0);

        let _ = extension.resolved_cache_size();
    }
}
