#![doc = include_str!("../README.md")]
#![doc(
    html_logo_url = "https://avatars.githubusercontent.com/u/16627100?s=200&v=4",
    html_favicon_url = "https://avatars.githubusercontent.com/u/16627100?s=200&v=4",
    issue_tracker_base_url = "https://github.com/base/base/issues/"
)]
#![cfg_attr(docsrs, feature(doc_cfg, doc_auto_cfg))]
#![cfg_attr(not(test), warn(unused_crate_dependencies))]

mod config;
pub use config::{ConfigError, L1ConfigFile, L2ConfigFile};

mod l1;
pub use l1::L1ClientArgs;

mod l2;
pub use l2::L2ClientArgs;

mod rpc;
pub use rpc::RpcArgs;

mod sequencer;
pub use sequencer::SequencerArgs;

pub mod signer;
pub use signer::{SignerArgs, SignerArgsParseError};

pub mod p2p;
pub use p2p::{P2PArgs, P2PConfigError};
