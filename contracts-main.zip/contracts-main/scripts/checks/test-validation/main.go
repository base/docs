package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"unicode"

	"github.com/BurntSushi/toml"
	"github.com/ethereum-optimism/optimism/op-chain-ops/solc"
	"github.com/base/contracts/scripts/checks/common"
)

// Main entry point

// Validates test function naming conventions and structure in Forge test artifacts
func main() {
	// Load exclusions from TOML file relative to script location
	scriptDir := filepath.Dir(os.Args[0])
	exclusionsPath := filepath.Join(scriptDir, "exclusions.toml")
	// Fall back to local path if running with go run
	if _, err := os.Stat(exclusionsPath); os.IsNotExist(err) {
		exclusionsPath = "scripts/checks/test-validation/exclusions.toml"
	}
	if err := loadExclusions(exclusionsPath); err != nil {
		fmt.Printf("error loading exclusions: %v\n", err)
		os.Exit(1)
	}

	if _, err := common.ProcessFilesGlob(
		[]string{"forge-artifacts/**/*.t.sol/*.json"},
		[]string{},
		processFile,
	); err != nil {
		fmt.Printf("error: %v\n", err)
		os.Exit(1)
	}

	fmt.Println("✅ All contract test validations passed")
}

// Processes a single test artifact file and runs all validations
func processFile(path string) (*common.Void, []error) {
	// Read and parse the Forge artifact file
	artifact, err := common.ReadForgeArtifact(path)
	if err != nil {
		return nil, []error{err}
	}

	var errors []error

	// Validate test function naming conventions
	testNameErrors := validateTestName(artifact)
	errors = append(errors, testNameErrors...)

	// Validate test function structure and organization
	structureErrors := validateTestStructure(artifact)
	errors = append(errors, structureErrors...)

	return nil, errors
}

// Test name validation

// Validates that test function names follow the expected naming conventions
func validateTestName(artifact *solc.ForgeArtifact) []error {
	var errors []error

	// Extract all test function names from the artifact
	names := extractTestNames(artifact)

	// Check each test name against naming conventions
	for _, name := range names {
		if err := checkTestName(name); err != nil {
			errors = append(errors, err)
		}
	}

	return errors
}

// Extracts all test function names from the artifact
func extractTestNames(artifact *solc.ForgeArtifact) []string {
	// Check if this is a test contract by looking for IS_TEST method
	isTest := false
	for _, entry := range artifact.Abi.Parsed.Methods {
		if entry.Name == "IS_TEST" {
			isTest = true
			break
		}
	}
	// Skip non-test contracts
	if !isTest {
		return nil
	}

	// Collect all method names that start with "test"
	names := []string{}
	for _, entry := range artifact.Abi.Parsed.Methods {
		if !strings.HasPrefix(entry.Name, "test") {
			continue
		}
		names = append(names, entry.Name)
	}

	return names
}

// Validates a single test name against all naming rules
func checkTestName(name string) error {
	// Split the test name into parts
	parts := strings.Split(name, "_")

	// Check each part against the defined validation rules
	for _, check := range checks {
		if !check.check(parts) {
			return fmt.Errorf("%s: %s", name, check.error)
		}
	}
	return nil
}

// Test structure validation

// Validates the overall structure and organization of test contracts
func validateTestStructure(artifact *solc.ForgeArtifact) []error {
	var errors []error

	// Extract file path from compilation target
	filePath, _, err := getCompilationTarget(artifact)
	if err != nil {
		errors = append(errors, err)
	}

	// Skip validation for excluded files
	if isExcluded(filePath) {
		return nil
	}

	// Validate test file path matches corresponding src path
	if !checkSrcPath(artifact) {
		errors = append(errors, fmt.Errorf("test file path does not match src path"))
	}

	// Validate contract name matches file path
	if !checkContractNameFilePath(artifact) {
		errors = append(errors, fmt.Errorf("contract name does not match file path"))
	}

	// Validate contract naming pattern structure
	structureErrors := checkTestStructure(artifact)
	errors = append(errors, structureErrors...)

	return errors
}

// Validates the contract naming pattern structure
func checkTestStructure(artifact *solc.ForgeArtifact) []error {
	var errors []error

	// Validate each contract name in the compilation target
	for _, contractName := range artifact.Metadata.Settings.CompilationTarget {
		if isExcludedTest(contractName) {
			continue
		}

		contractParts := strings.Split(contractName, "_")

		// Check for initialization test pattern
		if len(contractParts) == 2 && contractParts[1] == "TestInit" {
			// Pattern: <ContractName>_TestInit
			continue
		} else if len(contractParts) == 2 && contractParts[1] == "Harness" {
			// Pattern: <ContractName>_Harness
			continue
		} else if len(contractParts) == 3 && contractParts[2] == "Test" {
			errors = append(errors, checkTestMethodName(artifact, contractName, contractParts[1], "")...)
		} else if len(contractParts) == 3 && contractParts[2] == "Harness" {
			// Pattern: <ContractName>_<Descriptor>_Harness
			// (e.g., OPContractsManager_Upgrade_Harness)
			continue
		} else if len(contractParts) == 4 && contractParts[3] == "Test" {
			errors = append(errors, checkTestMethodName(artifact, contractName, contractParts[1], contractParts[2])...)
		} else {
			// Invalid naming pattern
			errors = append(errors, fmt.Errorf("contract '%s': invalid naming pattern. Expected patterns: <ContractName>_TestInit, <ContractName>_<FunctionName>_Test, or <ContractName>_Uncategorized_Test", contractName))
		}
	}

	return errors
}

func checkTestMethodName(artifact *solc.ForgeArtifact, contractName string, functionName string, _ string) []error {
	// Check for uncategorized test pattern
	allowedFunctionNames := []string{"Uncategorized", "Integration"}
	for _, allowed := range allowedFunctionNames {
		if functionName == allowed {
			// Pattern: <ContractName>_Uncategorized_Test or <ContractName>_Integration_Test
			return nil
		}
	}
	// Pattern: <ContractName>_<FunctionName>_Test - validate function exists
	if !checkFunctionExists(artifact, functionName) {
		// Convert to camelCase for error message
		camelCaseFunctionName := strings.ToLower(functionName[:1]) + functionName[1:]
		return []error{fmt.Errorf("contract '%s': function '%s' does not exist in source contract", contractName, camelCaseFunctionName)}
	}
	return nil
}

// Artifact and path validation helpers

// Extracts the compilation target from the artifact
func getCompilationTarget(artifact *solc.ForgeArtifact) (string, string, error) {
	// Return the first (and expected only) compilation target
	for filePath, contractName := range artifact.Metadata.Settings.CompilationTarget {
		return filePath, contractName, nil
	}

	// This should never happen since we already returned if we found a target,
	// but verify there's exactly one compilation target as expected
	if len(artifact.Metadata.Settings.CompilationTarget) != 1 {
		return "", "", fmt.Errorf("expected 1 compilation target, got %d", len(artifact.Metadata.Settings.CompilationTarget))
	}

	return "", "", nil
}

// Validates that the test file has a corresponding source file
func checkSrcPath(artifact *solc.ForgeArtifact) bool {
	for testFilePath := range artifact.Metadata.Settings.CompilationTarget {
		// Ensure file is in test directory with .t.sol extension
		if !strings.HasPrefix(testFilePath, "test/") || !strings.HasSuffix(testFilePath, ".t.sol") {
			return false
		}

		// Convert test path to corresponding source path
		srcPath := "src/" + strings.TrimPrefix(testFilePath, "test/")
		srcPath = strings.TrimSuffix(srcPath, ".t.sol") + ".sol"

		// Check if source file exists
		_, err := os.Stat(srcPath)
		if err != nil {
			return false
		}
	}

	return true
}

// Validates that contract name matches the file path
func checkContractNameFilePath(artifact *solc.ForgeArtifact) bool {
	for filePath, contractName := range artifact.Metadata.Settings.CompilationTarget {

		if isExcludedTest(contractName) {
			continue
		}

		// Split contract name to get the base contract name (before first underscore)
		contractParts := strings.Split(contractName, "_")
		// Split file path to get individual path components
		filePathParts := strings.Split(filePath, "/")

		// Extract filename without .t.sol extension
		fileName := strings.TrimSuffix(filePathParts[len(filePathParts)-1], ".t.sol")
		// Check if filename matches the base contract name
		if fileName != contractParts[0] {
			return false
		}
	}
	return true
}

// Finds the artifact file path for a given contract
func findArtifactPath(contractFileName, contractName string) (string, error) {
	// Construct the pattern to match the artifact file
	pattern := "forge-artifacts/" + contractFileName + "/" + contractName + "*.json"

	// Use filepath.Glob to find matching files
	files, err := filepath.Glob(pattern)

	// If no files found or there was an error, return an error
	if err != nil || len(files) == 0 {
		return "", fmt.Errorf("no artifact found for %s", contractName)
	}
	return files[0], nil
}

// Checks if the artifact represents a library
func isLibrary(artifact *solc.ForgeArtifact) bool {
	// Check the AST for ContractKind == "library"
	for _, node := range artifact.Ast.Nodes {
		if node.NodeType == "ContractDefinition" && node.ContractKind == "library" {
			return true
		}
	}
	return false
}

// Extracts function names from the AST (for libraries with internal functions)
func extractFunctionsFromAST(artifact *solc.ForgeArtifact) []string {
	var functions []string

	// Navigate through AST to find function definitions
	for _, node := range artifact.Ast.Nodes {
		if node.NodeType == "ContractDefinition" {
			// Iterate through contract nodes to find functions
			for _, childNode := range node.Nodes {
				if childNode.NodeType == "FunctionDefinition" && childNode.Name != "" {
					functions = append(functions, childNode.Name)
				}
			}
		}
	}

	return functions
}

// Validates that a function exists in the source contract
func checkFunctionExists(artifact *solc.ForgeArtifact, functionName string) bool {
	// Special functions always exist
	if strings.EqualFold(functionName, "constructor") || strings.EqualFold(functionName, "receive") || strings.EqualFold(functionName, "fallback") {
		return true
	}

	// Check each compilation target for the function
	for filePath := range artifact.Metadata.Settings.CompilationTarget {
		// Convert test path to source path
		srcPath := strings.TrimPrefix(filePath, "test/")
		srcPath = strings.TrimSuffix(srcPath, ".t.sol") + ".sol"

		// Extract contract name from file path
		pathParts := strings.Split(srcPath, "/")
		contractFileName := pathParts[len(pathParts)-1]
		contractName := strings.TrimSuffix(contractFileName, ".sol")

		// Find the corresponding source artifact
		srcArtifactPath, err := findArtifactPath(contractFileName, contractName)
		if err != nil {
			return false
		}

		// Read the source contract artifact
		srcArtifact, err := common.ReadForgeArtifact(srcArtifactPath)
		if err != nil {
			fmt.Printf("Failed to read artifact: %s, error: %v\n", srcArtifactPath, err)
			return false
		}

		// Check if source is a library - use AST for internal functions
		if isLibrary(srcArtifact) {
			functions := extractFunctionsFromAST(srcArtifact)
			for _, fn := range functions {
				if strings.EqualFold(fn, functionName) {
					return true
				}
			}
			return false
		}

		// For contracts, check if function exists in the ABI
		for _, method := range srcArtifact.Abi.Parsed.Methods {
			if strings.EqualFold(method.Name, functionName) {
				return true
			}
		}
	}
	return false
}

// Exclusion configuration

// Variables to hold exclusion lists loaded from TOML
var excludedPaths []string
var excludedTests []string

// Structure to match the TOML file format
type ExclusionsConfig struct {
	ExcludedPaths struct {
		SrcValidation          []string `toml:"src_validation"`
		ContractNameValidation []string `toml:"contract_name_validation"`
		FunctionNameValidation []string `toml:"function_name_validation"`
	} `toml:"excluded_paths"`
	ExcludedTests struct {
		Contracts []string `toml:"contracts"`
	} `toml:"excluded_tests"`
}

// Loads exclusion lists from the TOML configuration file
func loadExclusions(configPath string) error {
	var config ExclusionsConfig
	if _, err := toml.DecodeFile(configPath, &config); err != nil {
		return fmt.Errorf("failed to decode TOML file: %w", err)
	}

	// Combine all excluded paths into a single list
	excludedPaths = append(excludedPaths, config.ExcludedPaths.SrcValidation...)
	excludedPaths = append(excludedPaths, config.ExcludedPaths.ContractNameValidation...)
	excludedPaths = append(excludedPaths, config.ExcludedPaths.FunctionNameValidation...)

	// Load excluded test contracts
	excludedTests = config.ExcludedTests.Contracts

	return nil
}

// Checks if a file path should be excluded from validation
func isExcluded(filePath string) bool {
	for _, excluded := range excludedPaths {
		if strings.HasPrefix(filePath, excluded) {
			return true
		}
	}
	return false
}

// Checks if a contract name should be excluded from test validation
func isExcludedTest(contractName string) bool {
	for _, excluded := range excludedTests {
		if excluded == contractName {
			return true
		}
	}
	return false
}

// Defines the signature for test name validation functions
type CheckFunc func(parts []string) bool

// Contains validation logic and error message for a specific rule
type CheckInfo struct {
	error string
	check CheckFunc
}

// Defines all the validation rules for test names
var checks = map[string]CheckInfo{
	// Ensure no empty parts between underscores (e.g., "test__name" is invalid)
	"doubleUnderscores": {
		error: "test names cannot have double underscores",
		check: func(parts []string) bool {
			for _, part := range parts {
				if len(strings.TrimSpace(part)) == 0 {
					return false
				}
			}
			return true
		},
	},
	// Each part should start with lowercase letter (camelCase within parts is allowed)
	"camelCase": {
		error: "test name parts should be in camelCase",
		check: func(parts []string) bool {
			for _, part := range parts {
				if len(part) > 0 && unicode.IsUpper(rune(part[0])) {
					return false
				}
			}
			return true
		},
	},
	// Test names must have exactly 3 or 4 underscore-separated parts
	"partsCount": {
		error: "test names should have either 3 or 4 parts, each separated by underscores",
		check: func(parts []string) bool {
			return len(parts) == 3 || len(parts) == 4
		},
	},
	// First part must be one of the allowed test prefixes
	"prefix": {
		error: "test names should begin with 'test', 'testFuzz', or 'testDiff'",
		check: func(parts []string) bool {
			return len(parts) > 0 && (parts[0] == "test" || parts[0] == "testFuzz" || parts[0] == "testDiff")
		},
	},
	// Last part must indicate test outcome or be a benchmark
	"suffix": {
		error: "test names should end with either 'succeeds', 'reverts', 'fails', 'works', or 'benchmark[_num]'",
		check: func(parts []string) bool {
			if len(parts) == 0 {
				return false
			}
			last := parts[len(parts)-1]
			if last == "succeeds" || last == "reverts" || last == "fails" || last == "works" {
				return true
			}
			// Handle benchmark_<number> pattern
			if len(parts) >= 2 && parts[len(parts)-2] == "benchmark" {
				_, err := strconv.Atoi(last)
				return err == nil
			}
			return last == "benchmark"
		},
	},
	// Failure tests (ending with "reverts" or "fails") must have 4 parts to include failure reason
	"failureParts": {
		error: "failure tests should have 4 parts, third part should indicate the reason for failure",
		check: func(parts []string) bool {
			if len(parts) == 0 {
				return false
			}
			last := parts[len(parts)-1]
			return len(parts) == 4 || (last != "reverts" && last != "fails")
		},
	},
}
