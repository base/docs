#!/usr/bin/env bash
set -euo pipefail

# Pulls artifacts with conditional fallback based on branch and PR labels
# - PR branches: Use fallback by default (faster builds)
# - develop branch: Always build fresh (accuracy)
# - force-use-fresh-artifacts label: Override fallback (emergency escape hatch)

USE_FALLBACK=false

# Check if we're on a PR (not develop branch)
if [ "${CIRCLE_BRANCH:-}" != "develop" ]; then
  USE_FALLBACK=true

  # Check if PR has force-use-fresh-artifacts label (override fallback)
  # Get PR number from available sources
  PR_NUMBER=""

  # Try extracting from CIRCLE_PULL_REQUEST URL (internal PRs)
  if [ -n "${CIRCLE_PULL_REQUEST:-}" ]; then
    PR_NUMBER=$(echo "${CIRCLE_PULL_REQUEST}" | grep -o '[0-9]*$')
  # For external PRs, find PR via commit SHA
  elif [ -n "${CIRCLE_SHA1:-}" ]; then
    if PR_SEARCH=$(curl -sS --fail --connect-timeout 10 --max-time 30 -H "Authorization: token ${MISE_GITHUB_TOKEN}" \
      "https://api.github.com/repos/ethereum-optimism/optimism/commits/${CIRCLE_SHA1}/pulls" 2>/dev/null); then
      # Get the first PR number from the response
      PR_NUMBER=$(echo "$PR_SEARCH" | jq -r '.[0].number // empty' 2>/dev/null)
    fi
  fi

  if [ -n "$PR_NUMBER" ] && [ "$PR_NUMBER" != "null" ]; then
    # Query GitHub API for PR details (fail safe: proceed with fallback on error)
    if PR_DATA=$(curl -sS --fail --connect-timeout 10 --max-time 30 -H "Authorization: token ${MISE_GITHUB_TOKEN}" \
      "https://api.github.com/repos/ethereum-optimism/optimism/pulls/${PR_NUMBER}" 2>/dev/null); then

      if echo "$PR_DATA" | jq -e 'any(.labels[]; .name == "force-use-fresh-artifacts")' >/dev/null 2>&1; then
        echo "Force use fresh artifacts label detected, skipping fallback"
        USE_FALLBACK=false
      fi
    else
      echo "Warning: Failed to fetch PR labels from GitHub API, proceeding with fallback"
    fi
  fi
fi

# Ensure that PRs targetting anything other than develop do not use the fallback
TARGET_BRANCH="${TARGET_BRANCH:-unknown}"
if [ "$TARGET_BRANCH" != "develop" ]; then
  USE_FALLBACK=false
fi

# Pull artifacts with or without fallback
if [ "$USE_FALLBACK" = "true" ]; then
  bash scripts/ops/pull-artifacts.sh --fallback-to-latest
else
  bash scripts/ops/pull-artifacts.sh
fi
